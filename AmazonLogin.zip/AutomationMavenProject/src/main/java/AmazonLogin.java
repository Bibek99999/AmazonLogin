import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonLogin {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Development\\Downloads\\chromedriver_win32\\chromedriver.exe");
	WebDriver d=new ChromeDriver();
	d.get("https://www.amazon.in/");
	d.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]")).click();
	d.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("8527783419");
	d.findElement(By.xpath("//*[@id=\"continue\"]")).click();
	d.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("Bibek@7978");
	d.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
	String u=d.getCurrentUrl();
	if(u.equals("https://www.amazon.in/"))
	{
		System.out.println("Test Case Passed");
	}
	else
	{
		System.out.println("Test Case Failed");
	}
	//d.close();

	}

}
